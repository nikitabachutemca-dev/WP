<!DOCTYPE html> 
<html> 
<head> 
    <title>Book Details Submitted</title> 
</head> 
<body style="font-family: Arial; background-color: #eef2f3; padding: 30px;"> 
<h2> Book Details Submitted Successfully</h2> 
<?php 
if ($_SERVER["REQUEST_METHOD"] == "POST") { 
    $bookName = htmlspecialchars($_POST['book_name']); 
    $authorName = htmlspecialchars($_POST['author_name']); 
    $publisherName = htmlspecialchars($_POST['publisher_name']); 
    $category = htmlspecialchars($_POST['category']); 
    $synopsis = htmlspecialchars($_POST['synopsis']); 
    echo "<strong>Book Name:</strong> $bookName<br>"; 
    echo "<strong>Author Name:</strong> $authorName<br>"; 
    echo "<strong>Publisher Name:</strong> $publisherName<br>"; 
    echo "<strong>Category:</strong> $category<br>"; 
    echo "<strong>Synopsis:</strong><br><p>$synopsis</p>"; 
} else { 
    echo "No data submitted."; 
} 
?> 
<br><br> 
<a href="book_form.php">⬅ Go Back</a> 
</body> 
</html>
