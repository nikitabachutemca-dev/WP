<!DOCTYPE html>
<html>
<head>
  <title>Formatted Text</title>
</head>
<body>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $text  = $_POST['userText'];
    $color = $_POST['color'];
    $font  = $_POST['font'];
    $size  = $_POST['size'];
    $save  = $_POST['save'];

    // Save preferences in cookies if user selected "yes"
    if ($save == "yes") {
        setcookie("color", $color, time() + (86400 * 30)); // 30 days
        setcookie("font", $font, time() + (86400 * 30));
        setcookie("size", $size, time() + (86400 * 30));
    }

    echo "<h2>Your Formatted Text:</h2>";
    echo "<div style='color:$color; font-family:$font; font-size:{$size}px; border:1px solid #ccc; padding:10px; width:fit-content;'>";
    echo nl2br(htmlspecialchars($text));
    echo "</div>";

    echo "<br><a href='form.php'>← Go Back</a>";
}
?>

</body>
</html>
