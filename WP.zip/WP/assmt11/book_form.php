/* The code you provided is an HTML document that creates a form for entering book details. Here's a breakdown of what the code does: */
<DOCTYPE html> 
<html> 
<head> 
    <title>Book Details Form</title> 
    <style> 
        body { 
            font-family: Arial, sans-serif; 
            background-color: #f4f7f9; 
            padding: 30px; 
            display: flex; 
            justify-content: center; 
        } 
        .container { 
            background: white; 
            padding: 25px; 
            border-radius: 10px; 
            width: 450px; 
            box-shadow: 0 2px 8px rgba(0,0,0,0.2); 
        } 
        h2 { 
            text-align: center; 
            color: #333; 
        } 
        label { 
            font-weight: bold; 
        } 
        input[type=text], textarea, select { 
            width: 100%; 
            padding: 8px; 
            margin: 6px 0 15px; 
            border: 1px solid #ccc;  
            border-radius: 5px; 
        } 
        input[type=submit], input[type=reset] { 
            background-color: #007bff; 
            color: white; 
            border: none; 
            padding: 10px 15px; 
            border-radius: 5px; 
            cursor: pointer; 
        } 
        input[type=reset] { 
            background-color: #dc3545; 
        } 
        input[type=submit]:hover { 
            background-color: #0056b3; 
        } 
        input[type=reset]:hover { 
            background-color: #b02a37; 
        } 
    </style> 
</head> 
<body> 
<div class="container"> 
    <h2>📚 Book Details Form</h2> 
    <form method="post" action="book_display.php"> 
        <label>Book Name:</label> 
        <input type="text" name="book_name" required> 
        <label>Author Name:</label> 
        <input type="text" name="author_name" required> 
        <label>Publisher Name:</label> 
        <input type="text" name="publisher_name" required> 
        <label>Category:</label> 
        <select name="category" required> 
            <option value="">-- Select Category --</option> 
            <option value="Fiction">Fiction</option> 
            <option value="Non-fiction">Non-fiction</option> 
            <option value="Science">Science</option> 
            <option value="Technology">Technology</option> 
            <option value="Biography">Biography</option> 
        </select> 
        <label>Synopsis:</label> 
        <textarea name="synopsis" rows="5" required></textarea> 
        <input type="submit" value="Submit"> 
        <input type="reset" value="Reset"> 
    </form> 
</div> 
</body> 
</html>
