<!DOCTYPE html>
<html>
<head>
  <title>Text Formatter</title>
</head>
<body>
  <h2>🖋️ Text Formatter</h2>

  <form action="display.php" method="post">
    <textarea name="userText" rows="5" cols="40" placeholder="Enter your text here..."></textarea><br><br>

    <label>Choose Color:</label>
    <input type="color" name="color" value="<?php echo $_COOKIE['color'] ?? '#000000'; ?>"><br><br>

    <label>Choose Font:</label>
    <select name="font">
      <?php
        $fonts = ['Arial', 'Times New Roman', 'Courier New', 'Verdana'];
        $savedFont = $_COOKIE['font'] ?? '';
        foreach ($fonts as $font) {
          $selected = ($font == $savedFont) ? 'selected' : '';
          echo "<option value='$font' $selected>$font</option>";
        }
      ?>
    </select><br><br>

    <label>Font Size:</label>
    <input type="number" name="size" min="10" max="50" 
           value="<?php echo $_COOKIE['size'] ?? 16; ?>"> px<br><br>

    <label>Save preferences for next time?</label>
    <input type="radio" name="save" value="yes"> Yes
    <input type="radio" name="save" value="no" checked> No<br><br>

    <input type="submit" value="Format Text">
  </form>

</body>
</html>
