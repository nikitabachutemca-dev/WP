<!DOCTYPE html>
<html>
<head>
  <title>PHP Calculator Service (POST)</title>
</head>
<body>
  <h2>Calculator Web Service (POST)</h2>
  <form method="POST" action="calculator_service.php">
    Number 1: <input type="number" name="num1" required><br><br>
    Number 2: <input type="number" name="num2" required><br><br>

    Operation:
    <select name="operation" required>
      <option value="add">Add</option>
      <option value="subtract">Subtract</option>
      <option value="multiply">Multiply</option>
      <option value="divide">Divide</option>
    </select><br><br>

    <input type="submit" value="Calculate">
  </form>
</body>
</html>
