<?php
header("Content-Type: application/json");

// Check if the request method is POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve POST data safely
    $num1 = $_POST['num1'] ?? 0;
    $num2 = $_POST['num2'] ?? 0;
    $operation = $_POST['operation'] ?? '';

    $result = null;

    switch ($operation) {
        case 'add':
            $result = $num1 + $num2;
            break;
        case 'subtract':
            $result = $num1 - $num2;
            break;
        case 'multiply':
            $result = $num1 * $num2;
            break;
        case 'divide':
            $result = ($num2 != 0) ? $num1 / $num2 : 'Error: Division by zero';
            break;
        default:
            $result = 'Invalid operation';
    }

    // Return JSON response
    echo json_encode([
        "num1" => $num1,
        "num2" => $num2,
        "operation" => $operation,
        "result" => $result
    ]);
} else {
    echo json_encode(["error" => "Use POST method only"]);
}
?>
